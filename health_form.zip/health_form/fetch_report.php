<?php
$servername = "localhost";
$username = "root";
$password = "pass";
$dbname = "health_form_db";


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$email = $_GET['email'];


$sql = "SELECT report_path FROM users WHERE email='$email'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $reportPath = $row['report_path'];

   
    header("Content-type: application/pdf");
    header("Content-Disposition: inline; filename=health_report.pdf");
    readfile($reportPath);
} else {
    echo "No health report found for the given email ID.";
}

$conn->close();
?>
