<?php
$servername = "localhost";
$username = "root";
$password = "pass";
$dbname = "health_form_db";


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$name = $_POST['name'];
$age = $_POST['age'];
$weight = $_POST['weight'];
$email = $_POST['email'];


$targetDirectory = "uploads/";
$targetFile = $targetDirectory . basename($_FILES["report"]["name"]);
$uploadOk = 1;
$fileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));


if ($fileType != "pdf") {
    echo "Only PDF files are allowed.";
    $uploadOk = 0;
}


if ($uploadOk == 0) {
    echo "Sorry, there was an error uploading your file.";
} else {
    if (move_uploaded_file($_FILES["report"]["tmp_name"], $targetFile)) {
        
        $sql = "INSERT INTO users (name, age, weight, email, report_path) VALUES ('$name', $age, $weight, '$email', '$targetFile')";

        if ($conn->query($sql) === TRUE) {
            echo "User details and PDF file inserted successfully.";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}

$conn->close();
?>
